import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import type { BotStore, GuildConfig } from "./types";

const storePath = path.resolve(process.cwd(), "data", "discord-bot.json");
let data: BotStore = { guilds: {} };
let loaded = false;
let writeQueue = Promise.resolve();

export const defaultGuildConfig = (): GuildConfig => ({
  ticketChannelId: null,
  ticketMessageId: null,
  ticketText: "مرحباً بك، اضغط الزر لفتح تذكرة دعم.\nHello, click the button to open a support ticket.",
  ticketImage: null,
  welcomeChannelId: null,
  welcomeText: "أهلاً بك {user} في {server}!\nWelcome {user} to {server}!",
  welcomeImage: null,
  levelChannelId: null,
  levelText: "مبروك {user}! وصلت إلى المستوى {level}.\nCongratulations {user}, you reached level {level}.",
  levelImage: null,
  streakChannelId: null,
  streakText: "🔥 نظام الستريك",
  streakImage: null,
  streakSuccessText: "✅ نجاح الستريك! حصلت على نقطة.\n✅ Streak success! You earned a point.",
  streakFailureText: "❌ فشل الستريك! يمكنك إرسال ستريك مرة كل 12 ساعة فقط.\n❌ Streak failed! You can send a streak once every 12 hours.",
  streakSuccessImage: null,
  streakFailureImage: null,
  logChannels: {},
  prisonRoleId: null,
  prisonChannelId: null,
  studyChannelId: null,
  autoResponses: {},
  autoDeleteChannels: [],
  voice247ChannelId: null,
  users: {},
});

export async function initStore() {
  if (loaded) return;
  try {
    const raw = await readFile(storePath, "utf8");
    const parsed = JSON.parse(raw) as Partial<BotStore>;
    data = { guilds: parsed.guilds ?? {} };
  } catch {
    data = { guilds: {} };
  }
  loaded = true;
}

export function getGuildConfig(guildId: string): GuildConfig {
  const existing = data.guilds[guildId];
  if (existing) {
    const defaults = defaultGuildConfig();
    data.guilds[guildId] = {
      ...defaults,
      ...existing,
      logChannels: { ...defaults.logChannels, ...existing.logChannels },
      users: existing.users ?? {},
      autoResponses: existing.autoResponses ?? {},
      autoDeleteChannels: existing.autoDeleteChannels ?? [],
    };
    return data.guilds[guildId];
  }
  data.guilds[guildId] = defaultGuildConfig();
  return data.guilds[guildId];
}

export async function saveStore() {
  writeQueue = writeQueue.then(async () => {
    await mkdir(path.dirname(storePath), { recursive: true });
    await writeFile(storePath, JSON.stringify(data, null, 2), "utf8");
  });
  return writeQueue;
}