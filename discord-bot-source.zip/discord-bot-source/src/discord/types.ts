export type LogKind =
  | "join"
  | "leave"
  | "message"
  | "voice"
  | "mod"
  | "warn"
  | "role"
  | "channel"
  | "category"
  | "bot"
  | "server"
  | "invite"
  | "ticket";

export type UserProgress = {
  xp: number;
  level: number;
  streak: number;
  lastStreakAt: number | null;
};

export type GuildConfig = {
  ticketChannelId: string | null;
  ticketMessageId: string | null;
  ticketText: string;
  ticketImage: string | null;
  welcomeChannelId: string | null;
  welcomeText: string;
  welcomeImage: string | null;
  levelChannelId: string | null;
  levelText: string;
  levelImage: string | null;
  streakChannelId: string | null;
  streakText: string;
  streakImage: string | null;
  streakSuccessText: string;
  streakFailureText: string;
  streakSuccessImage: string | null;
  streakFailureImage: string | null;
  logChannels: Partial<Record<LogKind, string>>;
  prisonRoleId: string | null;
  prisonChannelId: string | null;
  studyChannelId: string | null;
  autoResponses: Record<string, string>;
  autoDeleteChannels: string[];
  voice247ChannelId: string | null;
  users: Record<string, UserProgress>;
};

export type BotStore = {
  guilds: Record<string, GuildConfig>;
};