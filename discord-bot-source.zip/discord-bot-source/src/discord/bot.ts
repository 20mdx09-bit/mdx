import {
  ActionRowBuilder,
  AttachmentBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  ChannelSelectMenuBuilder,
  Client,
  EmbedBuilder,
  Events,
  GatewayIntentBits,
  Guild,
  GuildMember,
  PermissionFlagsBits,
  PermissionsBitField,
  REST,
  Routes,
  SlashCommandBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  StringSelectMenuBuilder,
  type ChatInputCommandInteraction,
  type ModalSubmitInteraction,
  type ChatInputCommandInteraction as Interaction,
  type CategoryChannel,
  type GuildBasedChannel,
  type Message,
  type TextChannel,
} from "discord.js";
import {
  entersState,
  getVoiceConnection,
  joinVoiceChannel,
  VoiceConnectionStatus,
} from "@discordjs/voice";
import { logger } from "../lib/logger";
import { CHANNEL_LAYOUT, HELP_CATEGORIES, LEVEL_DEFINITIONS, LOG_NAMES, ROLE_DEFINITIONS } from "./constants";
import { getGuildConfig, initStore, saveStore } from "./store";
import type { GuildConfig, LogKind, UserProgress } from "./types";

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.GuildInvites,
  ],
});

const TWELVE_HOURS = 12 * 60 * 60 * 1000;
const TWENTY_FOUR_HOURS = 24 * 60 * 60 * 1000;
const setupSessions = new Map<string, {
  welcomeChannelId?: string;
  welcomeText?: string;
  welcomeImage?: string;
  ticketChannelId?: string;
  ticketText?: string;
  ticketImage?: string;
  levelChannelId?: string;
  levelText?: string;
  levelImage?: string;
  streakChannelId?: string;
  streakText?: string;
  streakImage?: string;
}>();
const guessGames = new Map<string, { answer: number; attempts: number }>();
const mathGames = new Map<string, { answer: number; question: string }>();

const imageOption = (name = "image", description = "صورة اختيارية / Optional image") =>
  (option: any) => option.setName(name).setDescription(description).setRequired(false);

const commands = [
  new SlashCommandBuilder().setName("help").setDescription("شرح جميع الأوامر بالتفصيل / Detailed command help")
    .addStringOption((o) => o.setName("category").setDescription("قسم محدد / Specific category").setRequired(false)
      .addChoices(...Object.keys(HELP_CATEGORIES).map((name) => ({ name, value: name })))),
  new SlashCommandBuilder().setName("bot-info").setDescription("شرح البوت وأنظمته كاملة / Full bot explanation"),
  new SlashCommandBuilder().setName("setup").setDescription("إعداد البوت خطوة بخطوة / Step-by-step bot setup").setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  new SlashCommandBuilder().setName("build-server").setDescription("بناء السيرفر كامل / Build the complete server").setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  new SlashCommandBuilder().setName("organize-server").setDescription("ترتيب الرومات والرتب / Organize channels and roles").setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  new SlashCommandBuilder().setName("setup-roles").setDescription("إنشاء الرتب المخصصة + رتب المستويات / Create custom and level roles").setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  new SlashCommandBuilder().setName("setup-channels").setDescription("إنشاء الأقسام والرومات / Create categories and channels").setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  new SlashCommandBuilder().setName("reset-server").setDescription("حذف رومات ورتب البوت التي أنشأها / Remove bot-created server structure").setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  new SlashCommandBuilder().setName("set").setDescription("تحديد إعدادات الرومات والنصوص / Configure channels and messages").setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand((s) => s.setName("ticket-channel").setDescription("تحديد روم ونص وصورة التذكرة / Set ticket channel, text and image")
      .addChannelOption((o) => o.setName("channel").setDescription("الروم / Channel").addChannelTypes(ChannelType.GuildText).setRequired(true))
      .addStringOption((o) => o.setName("text").setDescription("النص / Text").setRequired(false))
      .addAttachmentOption(imageOption()))
    .addSubcommand((s) => s.setName("welcome-channel").setDescription("تحديد الترحيب / Set welcome channel, text and image")
      .addChannelOption((o) => o.setName("channel").setDescription("الروم / Channel").addChannelTypes(ChannelType.GuildText).setRequired(true))
      .addStringOption((o) => o.setName("text").setDescription("النص، {user} و {server} متاحان / Text").setRequired(false))
      .addAttachmentOption(imageOption()))
    .addSubcommand((s) => s.setName("level-channel").setDescription("تحديد روم إشعارات المستويات / Set level channel")
      .addChannelOption((o) => o.setName("channel").setDescription("الروم / Channel").addChannelTypes(ChannelType.GuildText).setRequired(true))
      .addStringOption((o) => o.setName("text").setDescription("النص، {user} و {level} متاحان / Text").setRequired(false))
      .addAttachmentOption(imageOption()))
    .addSubcommand((s) => s.setName("streak-channel").setDescription("تحديد روم الستريك / Set streak channel")
      .addChannelOption((o) => o.setName("channel").setDescription("الروم / Channel").addChannelTypes(ChannelType.GuildText).setRequired(true))
      .addStringOption((o) => o.setName("text").setDescription("عنوان اللوحة / Panel text").setRequired(false))
      .addAttachmentOption(imageOption()))
    .addSubcommand((s) => s.setName("streak-messages").setDescription("تعديل نجاح وفشل الستريك / Set streak success and failure text")
      .addStringOption((o) => o.setName("success").setDescription("نص النجاح / Success text").setRequired(true))
      .addStringOption((o) => o.setName("failure").setDescription("نص الفشل / Failure text").setRequired(true))
      .addAttachmentOption((o) => o.setName("success-image").setDescription("صورة النجاح / Success image").setRequired(false))
      .addAttachmentOption((o) => o.setName("failure-image").setDescription("صورة الفشل / Failure image").setRequired(false)))
    .addSubcommand((s) => s.setName("log-channel").setDescription("تحديد روم سجل من النوع المختار / Set a log channel")
      .addStringOption((o) => o.setName("type").setDescription("نوع السجل / Log type").setRequired(true)
        .addChoices(...Object.entries(LOG_NAMES).map(([value, name]) => ({ name, value }))))
      .addChannelOption((o) => o.setName("channel").setDescription("الروم / Channel").addChannelTypes(ChannelType.GuildText).setRequired(true)))
    .addSubcommand((s) => s.setName("prison-role").setDescription("تحديد رتبة السجن / Set prison role")
      .addRoleOption((o) => o.setName("role").setDescription("الرتبة / Role").setRequired(true)))
    .addSubcommand((s) => s.setName("prison-channel").setDescription("تحديد روم السجن / Set prison channel")
      .addChannelOption((o) => o.setName("channel").setDescription("الروم / Channel").addChannelTypes(ChannelType.GuildText).setRequired(true)))
    .addSubcommand((s) => s.setName("study-channel").setDescription("تحديد روم الجلسات الدراسية / Set study channel")
      .addChannelOption((o) => o.setName("channel").setDescription("الروم / Channel").addChannelTypes(ChannelType.GuildText).setRequired(true))),
  new SlashCommandBuilder().setName("ticket").setDescription("نظام التذاكر / Ticket system")
    .addSubcommand((s) => s.setName("create").setDescription("إنشاء تذكرة / Open a ticket"))
    .addSubcommand((s) => s.setName("close").setDescription("إغلاق التذكرة / Close the current ticket"))
    .addSubcommand((s) => s.setName("setup").setDescription("إرسال اللوحة الدائمة / Send the persistent ticket panel")),
  new SlashCommandBuilder().setName("streak").setDescription("نظام الستريك / Streak system")
    .addSubcommand((s) => s.setName("daily").setDescription("تسجيل ستريك كل 12 ساعة / Claim every 12 hours"))
    .addSubcommand((s) => s.setName("check").setDescription("فحص الستريك / Check your streak"))
    .addSubcommand((s) => s.setName("leaderboard").setDescription("قائمة أعلى الستريكات / Streak leaderboard")),
  new SlashCommandBuilder().setName("rank").setDescription("عرض مستوى عضو / Show member level")
    .addUserOption((o) => o.setName("member").setDescription("عضو اختياري / Optional member").setRequired(false)),
  new SlashCommandBuilder().setName("leaderboard").setDescription("قائمة أعلى المستويات / Level leaderboard"),
  new SlashCommandBuilder().setName("message").setDescription("نظام الرسائل / Messaging system")
    .addSubcommand((s) => s.setName("dm").setDescription("إرسال رسالة خاصة / Send a direct message")
      .addUserOption((o) => o.setName("member").setDescription("العضو / Member").setRequired(true))
      .addStringOption((o) => o.setName("text").setDescription("النص / Text").setRequired(true))
      .addAttachmentOption(imageOption()))
    .addSubcommand((s) => s.setName("dm-all").setDescription("إرسال رسالة خاصة للجميع / DM all members")
      .addStringOption((o) => o.setName("text").setDescription("النص / Text").setRequired(true))
      .addAttachmentOption(imageOption()))
    .addSubcommand((s) => s.setName("announce").setDescription("إرسال إعلان في روم / Send an announcement")
      .addChannelOption((o) => o.setName("channel").setDescription("الروم / Channel").addChannelTypes(ChannelType.GuildText).setRequired(true))
      .addStringOption((o) => o.setName("text").setDescription("النص / Text").setRequired(true))
      .addAttachmentOption(imageOption())),
  new SlashCommandBuilder().setName("islamic").setDescription("محتوى ديني / Islamic content")
    .addSubcommand((s) => s.setName("quran").setDescription("عرض آية / Show a Quran verse"))
    .addSubcommand((s) => s.setName("dhikr").setDescription("عرض ذكر / Show dhikr"))
    .addSubcommand((s) => s.setName("dua").setDescription("عرض دعاء / Show dua")),
  new SlashCommandBuilder().setName("prison").setDescription("إدارة السجن / Prison administration").setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addSubcommand((s) => s.setName("add").setDescription("سجن عضو / Prison a member").addUserOption((o) => o.setName("member").setDescription("العضو / Member").setRequired(true)))
    .addSubcommand((s) => s.setName("release").setDescription("إطلاق عضو / Release a member").addUserOption((o) => o.setName("member").setDescription("العضو / Member").setRequired(true)))
    .addSubcommand((s) => s.setName("list").setDescription("قائمة المسجونين / Prison list")),
  new SlashCommandBuilder().setName("study").setDescription("الجلسات الدراسية / Study sessions").setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
    .addSubcommand((s) => s.setName("start").setDescription("بدء جلسة ساعتين / Start a two-hour session"))
    .addSubcommand((s) => s.setName("stop").setDescription("إيقاف الجلسة / Stop the session"))
    .addSubcommand((s) => s.setName("status").setDescription("حالة الجلسة / Session status")),
  new SlashCommandBuilder().setName("auto").setDescription("الردود والحذف التلقائي / Auto responses and deletion").setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addSubcommand((s) => s.setName("response-add").setDescription("إضافة رد تلقائي / Add auto response")
      .addStringOption((o) => o.setName("trigger").setDescription("الكلمة / Trigger").setRequired(true))
      .addStringOption((o) => o.setName("reply").setDescription("الرد / Reply").setRequired(true)))
    .addSubcommand((s) => s.setName("response-remove").setDescription("حذف رد تلقائي / Remove auto response").addStringOption((o) => o.setName("trigger").setDescription("الكلمة / Trigger").setRequired(true)))
    .addSubcommand((s) => s.setName("response-list").setDescription("قائمة الردود / List responses"))
    .addSubcommand((s) => s.setName("delete-set").setDescription("تفعيل الحذف التلقائي / Enable auto delete").addChannelOption((o) => o.setName("channel").setDescription("الروم / Channel").addChannelTypes(ChannelType.GuildText).setRequired(true)))
    .addSubcommand((s) => s.setName("delete-remove").setDescription("إيقاف الحذف التلقائي / Disable auto delete").addChannelOption((o) => o.setName("channel").setDescription("الروم / Channel").addChannelTypes(ChannelType.GuildText).setRequired(true))),
  new SlashCommandBuilder().setName("247").setDescription("البقاء في الروم الصوتي / Stay in voice").setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((s) => s.setName("start").setDescription("تفعيل 24/7 / Enable 24/7").addChannelOption((o) => o.setName("channel").setDescription("الروم الصوتي / Voice channel").addChannelTypes(ChannelType.GuildVoice).setRequired(true)))
    .addSubcommand((s) => s.setName("stop").setDescription("إيقاف 24/7 / Disable 24/7"))
    .addSubcommand((s) => s.setName("status").setDescription("حالة 24/7 / 24/7 status")),
  new SlashCommandBuilder().setName("ban").setDescription("حظر عضو / Ban a member").setDefaultMemberPermissions(PermissionFlagsBits.BanMembers).addUserOption((o) => o.setName("member").setDescription("العضو / Member").setRequired(true)).addStringOption((o) => o.setName("reason").setDescription("السبب / Reason").setRequired(false)),
  new SlashCommandBuilder().setName("kick").setDescription("طرد عضو / Kick a member").setDefaultMemberPermissions(PermissionFlagsBits.KickMembers).addUserOption((o) => o.setName("member").setDescription("العضو / Member").setRequired(true)).addStringOption((o) => o.setName("reason").setDescription("السبب / Reason").setRequired(false)),
  new SlashCommandBuilder().setName("timeout").setDescription("كتم مؤقت / Timeout a member").setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers).addUserOption((o) => o.setName("member").setDescription("العضو / Member").setRequired(true)).addIntegerOption((o) => o.setName("minutes").setDescription("الدقائق / Minutes").setRequired(true).setMinValue(1).setMaxValue(40320)),
  new SlashCommandBuilder().setName("untimeout").setDescription("رفع الكتم / Remove timeout").setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers).addUserOption((o) => o.setName("member").setDescription("العضو / Member").setRequired(true)),
  new SlashCommandBuilder().setName("unban").setDescription("رفع الحظر / Unban a user").setDefaultMemberPermissions(PermissionFlagsBits.BanMembers).addStringOption((o) => o.setName("user-id").setDescription("معرف المستخدم / User ID").setRequired(true)),
  new SlashCommandBuilder().setName("warn").setDescription("تحذير عضو / Warn a member").setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers).addUserOption((o) => o.setName("member").setDescription("العضو / Member").setRequired(true)).addStringOption((o) => o.setName("reason").setDescription("السبب / Reason").setRequired(true)),
  new SlashCommandBuilder().setName("clear").setDescription("حذف رسائل / Clear messages").setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages).addIntegerOption((o) => o.setName("amount").setDescription("العدد / Amount").setRequired(true).setMinValue(1).setMaxValue(100)),
  new SlashCommandBuilder().setName("heatstrip").setDescription("سلب رتب عضو / Remove a member's roles").setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles).addUserOption((o) => o.setName("member").setDescription("العضو / Member").setRequired(true)),
  new SlashCommandBuilder().setName("lock").setDescription("قفل الروم / Lock channel").setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),
  new SlashCommandBuilder().setName("unlock").setDescription("فتح الروم / Unlock channel").setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),
  new SlashCommandBuilder().setName("slowmode").setDescription("السلو مود / Slowmode").setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels).addIntegerOption((o) => o.setName("seconds").setDescription("الثواني، 0 للإيقاف / Seconds, 0 to disable").setRequired(true).setMinValue(0).setMaxValue(21600)),
  new SlashCommandBuilder().setName("hide").setDescription("إخفاء الروم / Hide channel").setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),
  new SlashCommandBuilder().setName("unhide").setDescription("إظهار الروم / Unhide channel").setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),
  new SlashCommandBuilder().setName("game").setDescription("ألعاب البوت / Bot games")
    .addSubcommand((s) => s.setName("help").setDescription("قائمة الألعاب / List games"))
    .addSubcommand((s) => s.setName("coinflip").setDescription("قلب العملة / Flip a coin"))
    .addSubcommand((s) => s.setName("dice").setDescription("رمي النرد / Roll dice").addIntegerOption((o) => o.setName("sides").setDescription("عدد الأوجه 2-100 / Sides 2-100").setRequired(false).setMinValue(2).setMaxValue(100)))
    .addSubcommand((s) => s.setName("rps").setDescription("حجر ورق مقص / Rock paper scissors")
      .addStringOption((o) => o.setName("choice").setDescription("اختيارك / Your choice").setRequired(true).addChoices(
        { name: "حجر / Rock", value: "rock" }, { name: "ورق / Paper", value: "paper" }, { name: "مقص / Scissors", value: "scissors" },
      )))
    .addSubcommand((s) => s.setName("slots").setDescription("آلة الحظ / Slot machine"))
    .addSubcommand((s) => s.setName("8ball").setDescription("اسأل الكرة السحرية / Ask the magic 8-ball").addStringOption((o) => o.setName("question").setDescription("السؤال / Question").setRequired(true)))
    .addSubcommand((s) => s.setName("math").setDescription("حل مسألة / Solve a math challenge")
      .addIntegerOption((o) => o.setName("answer").setDescription("إجابتك / Your answer").setRequired(false)))
    .addSubcommand((s) => s.setName("trivia").setDescription("سؤال معلومات عامة / Trivia question"))
    .addSubcommand((s) => s.setName("guess-start").setDescription("بدء لعبة التخمين / Start number guessing"))
    .addSubcommand((s) => s.setName("guess").setDescription("تخمين رقم من 1 إلى 100 / Guess 1-100").addIntegerOption((o) => o.setName("number").setDescription("رقمك / Your number").setRequired(true).setMinValue(1).setMaxValue(100)))
    .addSubcommand((s) => s.setName("blackjack").setDescription("بلاك جاك سريع / Quick blackjack")),
] as const;

function isGuildInteraction(interaction: ChatInputCommandInteraction): interaction is ChatInputCommandInteraction & { guild: Guild } {
  return Boolean(interaction.guild);
}

function cfgFor(interaction: ChatInputCommandInteraction) {
  return getGuildConfig(interaction.guildId!);
}

function replaceVars(text: string, interaction: ChatInputCommandInteraction, values: Record<string, string> = {}) {
  return text
    .replaceAll("{user}", `<@${interaction.user.id}>`)
    .replaceAll("{server}", interaction.guild?.name ?? "Server")
    .replaceAll("{level}", values.level ?? "")
    .replaceAll("{streak}", values.streak ?? "");
}

function isVideoUrl(url?: string | null) {
  return Boolean(url && /\.(mp4|webm|mov|m4v|avi)(\?|$)/i.test(url));
}

function embed(text: string, image?: string | null, color = 0x5865f2) {
  const result = new EmbedBuilder().setColor(color).setDescription(text).setTimestamp();
  if (image && !isVideoUrl(image)) result.setImage(image);
  return result;
}

function mediaPayload(text: string, image?: string | null) {
  return {
    embeds: [embed(text, image)],
    ...(image && isVideoUrl(image) ? { files: [image] } : {}),
  };
}

function setupSessionKey(interaction: { guildId: string | null; user: { id: string } }) {
  return `${interaction.guildId}:${interaction.user.id}`;
}

function setupChannelPrompt(stage: "welcome" | "ticket" | "level" | "streak") {
  const labels = {
    welcome: "👋 الخطوة 1/4: اختر روم الترحيب / Step 1/4: Choose welcome channel",
    ticket: "🎫 الخطوة 2/4: اختر روم التذاكر / Step 2/4: Choose ticket channel",
    level: "⭐ الخطوة 3/4: اختر روم المستويات / Step 3/4: Choose level channel",
    streak: "🔥 الخطوة 4/4: اختر روم الستريك / Step 4/4: Choose streak channel",
  };
  const select = new ChannelSelectMenuBuilder()
    .setCustomId(`setup:${stage}:channel`)
    .setPlaceholder(labels[stage])
    .setMinValues(1)
    .setMaxValues(1)
    .setChannelTypes(ChannelType.GuildText);
  const cancel = new ButtonBuilder().setCustomId("setup:cancel").setLabel("إلغاء / Cancel").setStyle(ButtonStyle.Secondary);
  return {
    content: labels[stage],
    components: [
      new ActionRowBuilder<ChannelSelectMenuBuilder>().addComponents(select),
      new ActionRowBuilder<ButtonBuilder>().addComponents(cancel),
    ],
  };
}

function setupContentModal(stage: "welcome" | "ticket" | "level" | "streak") {
  const labels = {
    welcome: ["setup_welcome_content", "نص الترحيب / Welcome text", "صورة أو فيديو URL / Image or video URL"],
    ticket: ["setup_ticket_content", "نص التذكرة / Ticket text", "صورة أو فيديو URL / Image or video URL"],
    level: ["setup_level_content", "نص المستوى / Level-up text", "صورة أو فيديو URL / Image or video URL"],
    streak: ["setup_streak_content", "عنوان الستريك / Streak panel text", "صورة أو فيديو URL / Image or video URL"],
  } as const;
  const [id, textLabel, imageLabel] = labels[stage];
  return new ModalBuilder()
    .setCustomId(id)
    .setTitle(textLabel)
    .addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder().setCustomId("text").setLabel(textLabel).setStyle(TextInputStyle.Paragraph).setRequired(true).setMaxLength(1000),
      ),
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder().setCustomId("image").setLabel(imageLabel).setStyle(TextInputStyle.Short).setRequired(false).setPlaceholder("https://..."),
      ),
    );
}

async function startSetup(interaction: ChatInputCommandInteraction) {
  setupSessions.set(setupSessionKey(interaction), {});
  await interaction.reply({
    embeds: [embed(
      "🧭 **الإعداد خطوة بخطوة / Step-by-step setup**\n\n" +
      "سأطلب منك بالترتيب: روم ونص وصورة الترحيب، ثم التذاكر، ثم المستويات، ثم الستريك. بعد ذلك ينشئ البوت الرومات والرتب والسجلات الافتراضية.\n" +
      "I will ask for the welcome, ticket, level and streak channel/text/media in order. Then the bot creates the default channels, roles and logs.\n\n" +
      "يمكنك وضع رابط صورة أو فيديو في النموذج. لرفع ملف مباشرة استخدم أوامر `/set` بعد انتهاء الإعداد.\n" +
      "You can enter an image/video URL in each form. To upload a file directly, use `/set` after setup.",
    )],
    components: [
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder().setCustomId("setup:begin").setLabel("ابدأ / Start").setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId("setup:cancel").setLabel("إلغاء / Cancel").setStyle(ButtonStyle.Secondary),
      ),
    ],
    ephemeral: true,
  });
}

type SetupStage = "welcome" | "ticket" | "level" | "streak";

function nextSetupStage(stage: SetupStage): SetupStage | null {
  const stages: SetupStage[] = ["welcome", "ticket", "level", "streak"];
  const index = stages.indexOf(stage);
  return stages[index + 1] ?? null;
}

async function handleSetupChannelSelection(interaction: any, stage: SetupStage) {
  if (!interaction.guildId) return;
  const session = setupSessions.get(setupSessionKey(interaction));
  if (!session) {
    await interaction.reply({ content: "انتهت جلسة الإعداد. ابدأ من جديد باستخدام `/setup`.\nThe setup session expired. Start again with `/setup`.", ephemeral: true });
    return;
  }
  const channelId = interaction.values[0];
  session[`${stage}ChannelId`] = channelId;
  await interaction.showModal(setupContentModal(stage));
}

async function handleSetupModal(interaction: ModalSubmitInteraction, stage: SetupStage) {
  const session = setupSessions.get(setupSessionKey(interaction));
  if (!session) {
    await interaction.reply({ content: "انتهت جلسة الإعداد. ابدأ من جديد باستخدام `/setup`.\nThe setup session expired. Start again with `/setup`.", ephemeral: true });
    return;
  }
  session[`${stage}Text`] = interaction.fields.getTextInputValue("text");
  const image = interaction.fields.getTextInputValue("image").trim();
  if (image) session[`${stage}Image`] = image;
  const next = nextSetupStage(stage);
  if (next) {
    await interaction.reply({ ...setupChannelPrompt(next), ephemeral: true });
  } else {
    await finishSetup(interaction);
  }
}

async function finishSetup(interaction: ChatInputCommandInteraction | ModalSubmitInteraction) {
  const session = setupSessions.get(setupSessionKey(interaction));
  if (!session?.welcomeChannelId || !session.ticketChannelId || !session.levelChannelId || !session.streakChannelId) {
    await reply(interaction, "❌ أكمل اختيار الرومات الأربعة أولاً.\n❌ Choose all four channels first.", undefined, true);
    return;
  }
  const cfg = getGuildConfig(interaction.guildId!);
  cfg.welcomeChannelId = session.welcomeChannelId;
  cfg.welcomeText = session.welcomeText ?? cfg.welcomeText;
  cfg.welcomeImage = session.welcomeImage ?? cfg.welcomeImage;
  cfg.ticketChannelId = session.ticketChannelId;
  cfg.ticketText = session.ticketText ?? cfg.ticketText;
  cfg.ticketImage = session.ticketImage ?? cfg.ticketImage;
  cfg.levelChannelId = session.levelChannelId;
  cfg.levelText = session.levelText ?? cfg.levelText;
  cfg.levelImage = session.levelImage ?? cfg.levelImage;
  cfg.streakChannelId = session.streakChannelId;
  cfg.streakText = session.streakText ?? cfg.streakText;
  cfg.streakImage = session.streakImage ?? cfg.streakImage;
  const result = await buildServer(interaction.guild!, cfg);
  setupSessions.delete(setupSessionKey(interaction));
  await reply(interaction,
    `✅ اكتمل الإعداد خطوة بخطوة.\n✅ Step-by-step setup is complete.\n\n` +
    `الرومات المخصصة / Configured channels:\n` +
    `👋 الترحيب: <#${session.welcomeChannelId}>\n🎫 التذاكر: <#${session.ticketChannelId}>\n⭐ المستويات: <#${session.levelChannelId}>\n🔥 الستريك: <#${session.streakChannelId}>\n\n` +
    `تم إنشاء ${result.roles.length} رتبة و${result.channels.length} روم/قسم.\nCreated ${result.roles.length} roles and ${result.channels.length} channels/categories.\n\n` +
    "استخدم `/ticket setup` لإرسال لوحة التذاكر، و`/bot-info` لشرح كل ما يفعله البوت.\nUse `/ticket setup` for the ticket panel and `/bot-info` for the complete guide.",
    undefined,
    true,
  );
}

function gameReply(text: string) {
  return mediaPayload(`🎮 **ألعاب البوت / Bot Games**\n\n${text}`);
}

async function handleGame(interaction: ChatInputCommandInteraction) {
  const sub = interaction.options.getSubcommand();
  if (sub === "help") {
    return reply(interaction,
      "🎮 **الألعاب المتاحة / Available games**\n\n" +
      "• `/game coinflip` — عملة / Coin flip\n" +
      "• `/game dice` — نرد من 2 إلى 100 وجه / 2-100 sided dice\n" +
      "• `/game rps` — حجر ورق مقص / Rock paper scissors\n" +
      "• `/game slots` — سلوت / Slot machine\n" +
      "• `/game 8ball` — الكرة السحرية / Magic 8-ball\n" +
      "• `/game math` — تحدي حساب / Math challenge\n" +
      "• `/game trivia` — معلومات عامة / Trivia\n" +
      "• `/game guess-start` ثم `/game guess` — تخمين رقم / Number guessing\n" +
      "• `/game blackjack` — بلاك جاك سريع / Quick blackjack",
    );
  }
  if (sub === "coinflip") return interaction.reply(gameReply(Math.random() < 0.5 ? "🪙 **صورة / Heads**" : "🪙 **كتابة / Tails**"));
  if (sub === "dice") {
    const sides = interaction.options.getInteger("sides") ?? 6;
    return interaction.reply(gameReply(`🎲 النتيجة / Result: **${Math.floor(Math.random() * sides) + 1}** من ${sides}`));
  }
  if (sub === "rps") {
    const choices = ["rock", "paper", "scissors"] as const;
    const botChoice = choices[Math.floor(Math.random() * choices.length)];
    const userChoice = interaction.options.getString("choice")!;
    const wins = userChoice === botChoice ? null : (userChoice === "rock" && botChoice === "scissors") || (userChoice === "paper" && botChoice === "rock") || (userChoice === "scissors" && botChoice === "paper");
    const names = { rock: "حجر / Rock", paper: "ورق / Paper", scissors: "مقص / Scissors" };
    return interaction.reply(gameReply(`أنت: **${names[userChoice as keyof typeof names]}**\nالبوت: **${names[botChoice]}**\n\n${wins === null ? "🤝 تعادل / Draw" : wins ? "🏆 فزت / You win" : "😄 فاز البوت / Bot wins"}`));
  }
  if (sub === "slots") {
    const icons = ["🍒", "🍋", "🍉", "⭐", "7️⃣"];
    const result = Array.from({ length: 3 }, () => icons[Math.floor(Math.random() * icons.length)]);
    const won = result.every((icon) => icon === result[0]);
    return interaction.reply(gameReply(`${result.join(" | ")}\n\n${won ? "🎉 جاكبوت! / Jackpot!" : "حظاً أوفر / Better luck next time"}`));
  }
  if (sub === "8ball") {
    const answers = ["نعم بالتأكيد / Definitely yes", "لا / No", "ربما / Maybe", "اسأل لاحقاً / Ask again later", "النتيجة ممتازة / Outlook is great", "لا أستطيع التنبؤ / Cannot predict now"];
    return interaction.reply(gameReply(`❓ ${interaction.options.getString("question")}\n🔮 ${answers[Math.floor(Math.random() * answers.length)]}`));
  }
  if (sub === "math") {
    const a = Math.floor(Math.random() * 20) + 1;
    const b = Math.floor(Math.random() * 20) + 1;
    const operator = ["+", "-", "×"][Math.floor(Math.random() * 3)];
    const answer = operator === "+" ? a + b : operator === "-" ? a - b : a * b;
    const key = `${interaction.guildId}:${interaction.user.id}`;
    const given = interaction.options.getInteger("answer");
    if (given !== null) {
      const game = mathGames.get(key);
      if (!game) return interaction.reply(gameReply("ابدأ تحدياً جديداً باستخدام `/game math`.\nStart a new challenge with `/game math`."));
      mathGames.delete(key);
      return interaction.reply(gameReply(given === game.answer ? "✅ إجابة صحيحة! / Correct answer!" : `❌ إجابة خاطئة. الصحيح: **${game.answer}** / Wrong. Correct: **${game.answer}**`));
    }
    mathGames.set(key, { answer, question: `${a} ${operator} ${b}` });
    return interaction.reply(gameReply(`🧮 احسب: **${a} ${operator} ${b} = ?**\nثم استخدم /game math مع خيار answer بعد الحل.\nThen use /game math with the answer option after solving.`));
  }
  if (sub === "trivia") {
    const questions = [
      ["ما هو أكبر كوكب؟ / What is the largest planet?", "المشتري / Jupiter"],
      ["كم عدد ألوان قوس قزح؟ / How many rainbow colors?", "7"],
      ["ما عاصمة اليابان؟ / Capital of Japan?", "طوكيو / Tokyo"],
      ["ما هو أسرع حيوان بري؟ / Fastest land animal?", "الفهد / Cheetah"],
    ];
    const [question, answer] = questions[Math.floor(Math.random() * questions.length)];
    return interaction.reply(gameReply(`❓ ${question}\n✅ الإجابة / Answer: **${answer}**`));
  }
  if (sub === "guess-start") {
    guessGames.set(`${interaction.guildId}:${interaction.user.id}`, { answer: Math.floor(Math.random() * 100) + 1, attempts: 0 });
    return interaction.reply(gameReply("بدأت لعبة التخمين! خمن رقماً من 1 إلى 100 باستخدام `/game guess number:50`.\nGuess a number from 1 to 100 using `/game guess number:50`."));
  }
  if (sub === "guess") {
    const key = `${interaction.guildId}:${interaction.user.id}`;
    const game = guessGames.get(key);
    if (!game) return interaction.reply(gameReply("ابدأ أولاً بـ `/game guess-start`.\nStart first with `/game guess-start`."));
    const number = interaction.options.getInteger("number")!;
    game.attempts += 1;
    if (number === game.answer) {
      guessGames.delete(key);
      return interaction.reply(gameReply(`🎉 صحيح! الرقم هو **${game.answer}** بعد ${game.attempts} محاولة.\nCorrect! The number was **${game.answer}** after ${game.attempts} attempts.`));
    }
    return interaction.reply(gameReply(`${number < game.answer ? "⬆️ الرقم أكبر / Higher" : "⬇️ الرقم أصغر / Lower"} — المحاولات / Attempts: ${game.attempts}`));
  }
  const draw = () => Math.floor(Math.random() * 10) + 2;
  const player = draw();
  const dealer = draw();
  return interaction.reply(gameReply(`🃏 أنت: **${player}**\n🃏 الموزع: **${dealer}**\n\n${player > 21 ? "خسرت، تجاوزت 21 / Bust, you lose" : dealer > 21 || player > dealer ? "🏆 فزت / You win" : player === dealer ? "🤝 تعادل / Draw" : "الموزع فاز / Dealer wins"}`));
}

type ReplyInteraction = ChatInputCommandInteraction | ModalSubmitInteraction;

async function reply(interaction: ReplyInteraction, text: string, image?: string | null, ephemeral = false) {
  const payload = { ...mediaPayload(text, image), ephemeral };
  if (interaction.replied || interaction.deferred) return interaction.editReply(payload);
  return interaction.reply(payload);
}

async function replyLong(interaction: ChatInputCommandInteraction, text: string, ephemeral = false) {
  const chunks: string[] = [];
  let current = "";
  for (const paragraph of text.split("\n")) {
    const next = current ? `${current}\n${paragraph}` : paragraph;
    if (next.length > 3800 && current) {
      chunks.push(current);
      current = paragraph;
    } else {
      current = next;
    }
  }
  if (current) chunks.push(current);
  const first = { ...mediaPayload(chunks.shift() ?? text), ephemeral };
  if (interaction.replied || interaction.deferred) await interaction.editReply(first);
  else await interaction.reply(first);
  for (const chunk of chunks) await interaction.followUp({ ...mediaPayload(chunk), ephemeral });
}

async function requireTextChannel(interaction: ChatInputCommandInteraction) {
  const channel = interaction.channel;
  if (!channel || channel.type !== ChannelType.GuildText) {
    await reply(interaction, "❌ يجب تنفيذ الأمر داخل روم كتابي.\n❌ This command must be used in a text channel.", undefined, true);
    return null;
  }
  return channel;
}

async function logEvent(guild: Guild, kind: LogKind, title: string, description: string) {
  const cfg = getGuildConfig(guild.id);
  const channelId = cfg.logChannels[kind] ?? cfg.logChannels.server;
  if (!channelId) return;
  const channel = await guild.channels.fetch(channelId).catch(() => null);
  if (!channel || channel.type !== ChannelType.GuildText) return;
  await channel.send({ embeds: [new EmbedBuilder().setColor(0x2b2d31).setTitle(title).setDescription(description).setTimestamp()] }).catch(() => undefined);
}

function progressFor(cfg: GuildConfig, userId: string): UserProgress {
  cfg.users[userId] ??= { xp: 0, level: 1, streak: 0, lastStreakAt: null };
  return cfg.users[userId];
}

function levelForXp(xp: number) {
  return Math.min(100, Math.floor(xp / 50) + 1);
}

function levelRoleName(level: number) {
  let result: string = LEVEL_DEFINITIONS[0][1];
  for (const [required, name] of LEVEL_DEFINITIONS) {
    if (level >= required) result = name;
  }
  return result;
}

async function updateLevelRole(member: GuildMember, level: number) {
  const roleName = levelRoleName(level);
  const target = member.guild.roles.cache.find((role) => role.name === roleName);
  if (!target) return;
  const levelRoles = member.guild.roles.cache.filter((role) => LEVEL_DEFINITIONS.some(([, name]) => name === role.name));
  await member.roles.remove(levelRoles).catch(() => undefined);
  await member.roles.add(target).catch(() => undefined);
}

async function setupRoles(guild: Guild) {
  const created: string[] = [];
  for (const definition of ROLE_DEFINITIONS) {
    if (guild.roles.cache.some((role) => role.name === definition.name)) continue;
    const role = await guild.roles.create({ name: definition.name, color: definition.color as any, reason: "Discord bot setup" }).catch(() => null);
    if (role) created.push(role.name);
  }
  for (const [, name] of LEVEL_DEFINITIONS) {
    if (guild.roles.cache.some((role) => role.name === name)) continue;
    const role = await guild.roles.create({ name, color: "#5865F2", reason: "Discord level system setup" }).catch(() => null);
    if (role) created.push(role.name);
  }
  return created;
}

function autoLogKind(name: string): LogKind | null {
  const mapping: Array<[string, LogKind]> = [
    ["join-logs", "join"], ["leave-logs", "leave"], ["message-logs", "message"], ["voice-logs", "voice"],
    ["mod-logs", "mod"], ["warn-logs", "warn"], ["role-logs", "role"], ["channel-logs", "channel"],
    ["category-logs", "category"], ["bot-logs", "bot"], ["server-logs", "server"], ["invite-logs", "invite"], ["ticket-logs", "ticket"],
  ];
  return mapping.find(([part]) => name.includes(part))?.[1] ?? null;
}

async function setupChannels(guild: Guild, cfg: GuildConfig) {
  const created: string[] = [];
  for (const [categoryName, layout] of Object.entries(CHANNEL_LAYOUT)) {
    let category = guild.channels.cache.find((channel) => channel.type === ChannelType.GuildCategory && channel.name === categoryName) as CategoryChannel | undefined;
    if (!category) {
      category = await guild.channels.create({ name: categoryName, type: ChannelType.GuildCategory, reason: "Discord bot setup" }).catch(() => undefined);
      if (category) created.push(category.name);
    }
    if (!category) continue;
    for (const name of layout.text) {
      let channel = guild.channels.cache.find((item) => item.type === ChannelType.GuildText && item.name === name) as TextChannel | undefined;
      if (!channel) channel = await guild.channels.create({ name, type: ChannelType.GuildText, parent: category.id, reason: "Discord bot setup" }).catch(() => undefined);
      if (channel) {
        if (!guild.channels.cache.some((item) => item.id === channel.id)) created.push(channel.name);
        const kind = autoLogKind(name);
        if (kind) cfg.logChannels[kind] = channel.id;
      }
    }
    for (const name of layout.voice) {
      if (guild.channels.cache.some((item) => item.type === ChannelType.GuildVoice && item.name === name)) continue;
      const channel = await guild.channels.create({ name, type: ChannelType.GuildVoice, parent: category.id, reason: "Discord bot setup" }).catch(() => null);
      if (channel) created.push(channel.name);
    }
  }
  return created;
}

async function openTicket(interaction: ChatInputCommandInteraction, cfg: GuildConfig) {
  const guild = interaction.guild!;
  const member = interaction.member as GuildMember;
  const existing = guild.channels.cache.find((channel) => channel.type === ChannelType.GuildText && channel.name === `ticket-${interaction.user.username.toLowerCase()}`);
  if (existing) {
    await reply(interaction, `لديك تذكرة مفتوحة بالفعل: ${existing}\nYou already have an open ticket: ${existing}`, undefined, true);
    return;
  }
  let category = guild.channels.cache.find((channel) => channel.type === ChannelType.GuildCategory && (channel.name === "𓍯 Support" || channel.name.toLowerCase() === "support"));
  if (!category) category = await guild.channels.create({ name: "𓍯 Support", type: ChannelType.GuildCategory, reason: "Ticket category" }).catch(() => undefined);
  const channel = await guild.channels.create({
    name: `ticket-${interaction.user.username.toLowerCase().replace(/[^a-z0-9-]/g, "").slice(0, 20) || interaction.user.id.slice(-6)}`,
    type: ChannelType.GuildText,
    parent: category?.id,
    permissionOverwrites: [
      { id: guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
      { id: member.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.AttachFiles] },
      { id: guild.members.me!.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.ManageChannels] },
    ],
    reason: "Ticket opened",
  }).catch(() => null);
  if (!channel) {
    await reply(interaction, "❌ فشل إنشاء التذكرة. تأكد من صلاحيات البوت.\n❌ Failed to create ticket. Check bot permissions.", undefined, true);
    return;
  }
  const closeRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("ticket:close").setLabel("إغلاق التذكرة / Close").setStyle(ButtonStyle.Danger),
  );
  await channel.send({ content: `<@${member.id}>`, embeds: [embed(replaceVars(cfg.ticketText, interaction), cfg.ticketImage)], components: [closeRow] });
  await logEvent(guild, "ticket", "🎫 Ticket opened / تم فتح تذكرة", `${member} opened ${channel}`);
  await reply(interaction, `✅ تم إنشاء التذكرة: ${channel}\n✅ Ticket created: ${channel}`, undefined, true);
}

async function buildServer(guild: Guild, cfg: GuildConfig) {
  const roles = await setupRoles(guild);
  const channels = await setupChannels(guild, cfg);
  await saveStore();
  await logEvent(guild, "server", "🏗️ Server built / تم بناء السيرفر", `Roles: ${roles.length}\nChannels: ${channels.length}`);
  return { roles, channels };
}

async function handleSet(interaction: ChatInputCommandInteraction) {
  const cfg = cfgFor(interaction);
  const subcommand = interaction.options.getSubcommand();
  const channel = interaction.options.getChannel("channel");
  const image = interaction.options.getAttachment("image")?.url ?? null;
  if (subcommand === "ticket-channel") {
    cfg.ticketChannelId = channel!.id;
    cfg.ticketText = interaction.options.getString("text") ?? cfg.ticketText;
    if (image) cfg.ticketImage = image;
  } else if (subcommand === "welcome-channel") {
    cfg.welcomeChannelId = channel!.id;
    cfg.welcomeText = interaction.options.getString("text") ?? cfg.welcomeText;
    if (image) cfg.welcomeImage = image;
  } else if (subcommand === "level-channel") {
    cfg.levelChannelId = channel!.id;
    cfg.levelText = interaction.options.getString("text") ?? cfg.levelText;
    if (image) cfg.levelImage = image;
  } else if (subcommand === "streak-channel") {
    cfg.streakChannelId = channel!.id;
    cfg.streakText = interaction.options.getString("text") ?? cfg.streakText;
    if (image) cfg.streakImage = image;
  } else if (subcommand === "streak-messages") {
    cfg.streakSuccessText = interaction.options.getString("success")!;
    cfg.streakFailureText = interaction.options.getString("failure")!;
    cfg.streakSuccessImage = interaction.options.getAttachment("success-image")?.url ?? cfg.streakSuccessImage;
    cfg.streakFailureImage = interaction.options.getAttachment("failure-image")?.url ?? cfg.streakFailureImage;
  } else if (subcommand === "log-channel") {
    cfg.logChannels[interaction.options.getString("type") as LogKind] = channel!.id;
  } else if (subcommand === "prison-role") {
    cfg.prisonRoleId = interaction.options.getRole("role")!.id;
  } else if (subcommand === "prison-channel") {
    cfg.prisonChannelId = channel!.id;
  } else if (subcommand === "study-channel") {
    cfg.studyChannelId = channel!.id;
  }
  await saveStore();
  await logEvent(interaction.guild!, "server", "⚙️ Setting changed / تم تغيير إعداد", `/${subcommand} by ${interaction.user}`);
  await reply(interaction, `✅ تم حفظ إعداد ${subcommand} بنجاح.\n✅ ${subcommand} saved successfully.`);
}

function detailedHelp(category?: string) {
  if (category && HELP_CATEGORIES[category]) {
    return `**${category}**\n${HELP_CATEGORIES[category].map((command) => `• \`${command}\` — استخدم الأمر مع الخيارات الظاهرة لشرح التفاصيل / use the shown options for details`).join("\n")}`;
  }
  return Object.entries(HELP_CATEGORIES).map(([name, list]) => `**${name}**\n${list.map((command) => `• \`${command}\``).join("  ")}`).join("\n\n") +
    "\n\n**الصلاحيات / Permissions:** أوامر الإعداد والإشراف والإدارة للطاقم فقط، والتذكرة والستريك والرتبة للأعضاء. / Setup, moderation and admin commands are staff-only; ticket, streak and rank are available to members.";
}

async function handleCommand(interaction: ChatInputCommandInteraction) {
  if (!isGuildInteraction(interaction)) {
    await reply(interaction, "❌ هذا الأمر يعمل داخل السيرفر فقط.\n❌ This command only works inside a server.", undefined, true);
    return;
  }
  const guild = interaction.guild;
  const cfg = cfgFor(interaction);
  const command = interaction.commandName;
  try {
    if (command === "help") return reply(interaction, detailedHelp(interaction.options.getString("category") ?? undefined));
    if (command === "setup") return startSetup(interaction);
    if (command === "game") return handleGame(interaction);
    if (command === "bot-info") return replyLong(interaction,
      "🤖 **شرح البوت كامل / Complete Bot Guide**\n\n" +
      "**ما الذي يفعله البوت؟ / What does the bot do?**\n" +
      "بوت إدارة مجتمع ثنائي اللغة ينظم السيرفر، ينشئ الرومات والرتب، يدير التذاكر، الترحيب، الستريك، المستويات، الرسائل، السجلات وأدوات الإشراف.\n" +
      "A bilingual community-management bot that organizes the server, creates channels and roles, and handles tickets, welcomes, streaks, levels, messaging, logs and moderation.\n\n" +
      "**🎟️ التذاكر / Tickets**\n" +
      "لوحة دائمة بزر فتح التذكرة، إنشاء روم خاص للعضو، زر إغلاق، وسجل فتح/إغلاق التذاكر. يمكنك تغيير روم اللوحة والنص وإضافة صورة أو فيديو واحد.\n" +
      "Persistent panel with an open button, private ticket channel, close button and ticket logs. The panel channel, text and one image/video are customizable.\n" +
      "الأوامر / Commands: `/ticket setup` `/ticket create` `/ticket close`\n\n" +
      "**👋 الترحيب / Welcome**\n" +
      "يرسل رسالة ترحيب عند دخول عضو جديد مع نص وصورة أو فيديو في الروم الذي تحدده.\n" +
      "Sends a welcome message when a member joins, with customizable text and one image/video.\n" +
      "الإعداد / Setup: `/set welcome-channel`\n\n" +
      "**🔥 الستريك / Streak**\n" +
      "محاولة ناجحة واحدة كل 12 ساعة. المحاولة قبل الموعد تظهر فشل ولا تضيف نقطة. إذا مر أكثر من 24 ساعة بدون ستريك يتم تصفير العدد.\n" +
      "One successful claim every 12 hours. An early attempt fails and gives no point. The streak resets after more than 24 hours without a claim.\n" +
      "الأوامر / Commands: `/streak daily` `/streak check` `/streak leaderboard`\n\n" +
      "**⭐ المستويات والـ XP / Levels and XP**\n" +
      "يحصل الأعضاء على XP من الرسائل، ويتغير مستوى العضو تلقائياً من Level 1 إلى Level 100، مع إنشاء وإسناد رتبة المستوى عند الترقية.\n" +
      "Members earn XP from messages, level up automatically from Level 1 to Level 100, and receive the matching level role.\n" +
      "الأوامر / Commands: `/rank` `/leaderboard`\n\n" +
      "**📜 السجلات / Logs**\n" +
      "يسجل الانضمام، المغادرة، تعديل وحذف الرسائل، الصوتي، الإشراف، التحذيرات، الرتب، الرومات، الأقسام، التذاكر، الدعوات، البوت والسيرفر. لكل نوع سجل روم مستقل قابل للتحديد.\n" +
      "Logs joins, leaves, edited/deleted messages, voice, moderation, warnings, roles, channels, categories, tickets, invites, bot and server events. Each log type can use its own channel.\n" +
      "الإعداد / Setup: `/set log-channel`\n\n" +
      "**📨 الرسائل / Messaging**\n" +
      "إرسال خاص لعضو، إرسال خاص للأعضاء، أو إعلان في روم محدد. كل رسالة تدعم نصاً وصورة أو فيديو واحداً.\n" +
      "DM one member, DM members, or announce in a selected channel. Every message supports text and one image/video.\n" +
      "الأوامر / Commands: `/message dm` `/message dm-all` `/message announce`\n\n" +
      "**🛡️ الإدارة والإشراف / Admin and Moderation**\n" +
      "حظر، طرد، كتم مؤقت، رفع الكتم، رفع الحظر، تحذير، حذف رسائل، قفل وفتح الرومات، السلو مود، إخفاء وإظهار الرومات، وسلب الرتب.\n" +
      "Ban, kick, timeout, remove timeout, unban, warn, clear messages, lock/unlock channels, slowmode, hide/unhide channels and remove roles.\n\n" +
      "**⚙️ الأنظمة الإضافية / Extra Systems**\n" +
      "السجن وإطلاق الأعضاء، جلسات دراسية، ردود تلقائية، حذف تلقائي، ووضع صوتي 24/7.\n" +
      "Prison/release, study sessions, auto responses, auto deletion and 24/7 voice mode.\n\n" +
      "**🚀 طريقة البدء / How to start**\n" +
      "1. استخدم `/build-server` لبناء الرتب والرومات الأساسية.\n" +
      "2. استخدم `/set` لتحديد رومات التذاكر والترحيب والستريك والمستويات والسجلات.\n" +
      "3. استخدم `/ticket setup` لإرسال لوحة التذاكر.\n" +
      "4. استخدم `/help` لرؤية الأوامر مقسمة حسب الأقسام.\n" +
      "1. Run `/build-server` to create the base roles and channels.\n" +
      "2. Use `/set` to configure ticket, welcome, streak, level and log channels.\n" +
      "3. Run `/ticket setup` to send the ticket panel.\n" +
      "4. Use `/help` for commands grouped by category.\n\n" +
      "**🔐 الصلاحيات المطلوبة / Required permissions**\n" +
      "يحتاج البوت إلى إدارة الرومات والرتب والرسائل والأعضاء، بالإضافة إلى Ban/Kick/Moderate Members حسب الأوامر المستخدمة. فعّل Message Content Intent وServer Members Intent من بوابة Discord.\n" +
      "The bot needs channel, role, message and member management permissions, plus Ban/Kick/Moderate Members for related commands. Enable Message Content Intent and Server Members Intent in the Discord Developer Portal.\n\n" +
      "**🧭 الإعداد التفاعلي / Interactive setup**\n" +
      "استخدم `/setup` ليطلب منك البوت اختيار كل روم ثم يفتح نموذجاً للنص والصورة أو الفيديو، وينتقل للخطوة التالية تلقائياً.\n" +
      "Use `/setup` to choose each channel, enter its text and image/video, and move automatically to the next step.\n\n" +
      "**🎮 الألعاب / Games**\n" +
      "يحتوي `/game` على العملة، النرد، حجر ورق مقص، السلوت، الكرة السحرية، تحدي الرياضيات، المعلومات العامة، تخمين الرقم والبلاك جاك.\n" +
      "`/game` includes coin flip, dice, rock-paper-scissors, slots, magic 8-ball, math, trivia, number guessing and blackjack.\n\n" +
      "كل الردود بالعربي والإنجليزي، والإعدادات محفوظة لكل سيرفر بشكل مستقل.\n" +
      "All replies are bilingual, and settings are saved independently for each server.");
    if (command === "setup-roles") {
      await interaction.deferReply();
      const names = await setupRoles(guild);
      await saveStore();
      return interaction.editReply(mediaPayload(`✅ تم إنشاء ${names.length} رتبة جديدة.\n✅ Created ${names.length} new roles.\n${names.join(", ")}`));
    }
    if (command === "setup-channels") {
      await interaction.deferReply();
      const names = await setupChannels(guild, cfg);
      await saveStore();
      return interaction.editReply(mediaPayload(`✅ تم إنشاء ${names.length} روم/قسم جديد.\n✅ Created ${names.length} new channels/categories.`));
    }
    if (command === "build-server" || command === "organize-server") {
      await interaction.deferReply();
      const result = await buildServer(guild, cfg);
      return interaction.editReply(mediaPayload(`✅ اكتمل ترتيب السيرفر.\n✅ Server organization completed.\nالرتب: ${result.roles.length} | الرومات: ${result.channels.length}`));
    }
    if (command === "reset-server") {
      await interaction.deferReply();
      const botCategories = guild.channels.cache.filter((channel) => channel.type === ChannelType.GuildCategory && Object.keys(CHANNEL_LAYOUT).includes(channel.name));
      for (const category of botCategories.values()) await category.delete("Bot reset").catch(() => undefined);
      const botRoles = guild.roles.cache.filter((role) => ROLE_DEFINITIONS.some((item) => item.name === role.name) || LEVEL_DEFINITIONS.some(([, name]) => name === role.name));
      for (const role of botRoles.values()) await role.delete("Bot reset").catch(() => undefined);
      cfg.logChannels = {};
      await saveStore();
      return interaction.editReply(mediaPayload("⚠️ تم حذف الهيكل الذي أنشأه البوت.\n⚠️ Bot-created structure was removed."));
    }
    if (command === "set") return handleSet(interaction);

    if (command === "ticket") {
      const sub = interaction.options.getSubcommand();
      if (sub === "create") return openTicket(interaction, cfg);
      if (sub === "setup") {
        const channel = await requireTextChannel(interaction);
        if (!channel) return;
        if (!cfg.ticketChannelId) cfg.ticketChannelId = channel.id;
        const row = new ActionRowBuilder<ButtonBuilder>().addComponents(new ButtonBuilder().setCustomId("ticket:open").setLabel("فتح تذكرة / Open ticket").setStyle(ButtonStyle.Primary));
        const message = await channel.send({ embeds: [embed(replaceVars(cfg.ticketText, interaction), cfg.ticketImage)], components: [row] });
        cfg.ticketMessageId = message.id;
        await saveStore();
        return reply(interaction, `✅ تم إرسال لوحة التذكرة في ${channel}.\n✅ Ticket panel sent to ${channel}.`, undefined, true);
      }
      if (sub === "close") {
        const textChannel = await requireTextChannel(interaction);
        if (!textChannel || !textChannel.name.startsWith("ticket-")) return reply(interaction, "❌ هذا ليس روم تذكرة.\n❌ This is not a ticket channel.", undefined, true);
        await reply(interaction, "✅ سيتم إغلاق التذكرة الآن.\n✅ This ticket will close now.");
        await logEvent(guild, "ticket", "🎫 Ticket closed / أغلقت التذكرة", `${textChannel} by ${interaction.user}`);
        setTimeout(() => textChannel.delete("Ticket closed").catch(() => undefined), 1500);
        return;
      }
    }

    if (command === "streak") {
      const sub = interaction.options.getSubcommand();
      if (cfg.streakChannelId && interaction.channelId !== cfg.streakChannelId) return reply(interaction, `❌ استخدم الستريك في <#${cfg.streakChannelId}>.\n❌ Use streak in <#${cfg.streakChannelId}>.`, undefined, true);
      if (sub === "daily") {
        const progress = progressFor(cfg, interaction.user.id);
        const now = Date.now();
        if (progress.lastStreakAt && now - progress.lastStreakAt < TWELVE_HOURS) {
          return reply(interaction, replaceVars(cfg.streakFailureText, interaction, { streak: String(progress.streak) }), cfg.streakFailureImage);
        }
        if (progress.lastStreakAt && now - progress.lastStreakAt > TWENTY_FOUR_HOURS) progress.streak = 0;
        progress.streak += 1;
        progress.lastStreakAt = now;
        await saveStore();
        return reply(interaction, `${replaceVars(cfg.streakSuccessText, interaction, { streak: String(progress.streak) })}\n🔥 Streak: **${progress.streak}**`, cfg.streakSuccessImage);
      }
      if (sub === "check") {
        const progress = progressFor(cfg, interaction.user.id);
        if (progress.lastStreakAt && Date.now() - progress.lastStreakAt > TWENTY_FOUR_HOURS) progress.streak = 0;
        return reply(interaction, `🔥 ستريكك: **${progress.streak}**\n🔥 Your streak: **${progress.streak}**`, cfg.streakImage);
      }
      const rows = Object.entries(cfg.users).sort((a, b) => b[1].streak - a[1].streak).slice(0, 10);
      return reply(interaction, `🔥 **Streak leaderboard / أعلى الستريكات**\n${rows.length ? rows.map(([id, user], index) => `${index + 1}. <@${id}> — ${user.streak}`).join("\n") : "لا توجد بيانات / No data"}`, cfg.streakImage);
    }

    if (command === "rank" || command === "leaderboard") {
      if (command === "rank") {
        const user = interaction.options.getUser("member") ?? interaction.user;
        const progress = progressFor(cfg, user.id);
        return reply(interaction, `⭐ **Rank / الرتبة**\n${user}\nLevel: **${progress.level}**\nXP: **${progress.xp}**\nRole: **${levelRoleName(progress.level)}**`);
      }
      const rows = Object.entries(cfg.users).sort((a, b) => b[1].level - a[1].level || b[1].xp - a[1].xp).slice(0, 10);
      return reply(interaction, `⭐ **Level leaderboard / أعلى المستويات**\n${rows.length ? rows.map(([id, user], index) => `${index + 1}. <@${id}> — Level ${user.level} (${user.xp} XP)`).join("\n") : "لا توجد بيانات / No data"}`);
    }

    if (command === "message") {
      const sub = interaction.options.getSubcommand();
      const text = interaction.options.getString("text")!;
      const image = interaction.options.getAttachment("image")?.url;
      if (sub === "dm") {
        const member = interaction.options.getUser("member")!;
        await member.send(mediaPayload(text, image)).catch(() => null);
        return reply(interaction, `✅ تم إرسال الرسالة إلى ${member}.\n✅ Message sent to ${member}.`, undefined, true);
      }
      if (sub === "announce") {
        const channel = interaction.options.getChannel("channel");
        if (!channel || channel.type !== ChannelType.GuildText) return reply(interaction, "❌ اختر روم كتابي.\n❌ Choose a text channel.", undefined, true);
        await (channel as TextChannel).send(mediaPayload(text, image));
        await logEvent(guild, "server", "📨 Announcement / إعلان", `${interaction.user} sent an announcement to ${channel}`);
        return reply(interaction, "✅ تم إرسال الإعلان.\n✅ Announcement sent.", undefined, true);
      }
      await interaction.deferReply({ ephemeral: true });
      let sent = 0;
      for (const member of guild.members.cache.filter((member) => !member.user.bot).values()) {
        if (member.user.id === interaction.user.id) continue;
        if (await member.send(mediaPayload(text, image)).then(() => true).catch(() => false)) sent += 1;
        await new Promise((resolve) => setTimeout(resolve, 350));
      }
      return interaction.editReply(mediaPayload(`✅ تم إرسال الرسالة إلى ${sent} عضو.\n✅ Message sent to ${sent} members.`));
    }

    if (command === "islamic") {
      const content = {
        quran: "﴿إِنَّ مَعَ الْعُسْرِ يُسْرًا﴾\nIndeed, with hardship comes ease. (Quran 94:6)",
        dhikr: "سبحان الله، والحمد لله، والله أكبر.\nGlory be to Allah, praise be to Allah, Allah is the Greatest.",
        dua: "اللهم اغفر لنا وارحمنا واهدنا.\nO Allah, forgive us, have mercy on us, and guide us.",
      }[interaction.options.getSubcommand() as "quran" | "dhikr" | "dua"];
      return reply(interaction, content);
    }

    if (command === "prison") {
      const sub = interaction.options.getSubcommand();
      if (sub === "list") {
        const role = cfg.prisonRoleId ? guild.roles.cache.get(cfg.prisonRoleId) : null;
        return reply(interaction, role ? `🔒 **Prison list / قائمة السجن**\n${role.members.map((member) => `• ${member}`).join("\n") || "فارغة / Empty"}` : "❌ حدد رتبة السجن أولاً باستخدام `/set prison-role`.\n❌ Set a prison role first with `/set prison-role`.");
      }
      const member = interaction.options.getMember("member") as GuildMember | null;
      if (!member) return reply(interaction, "❌ العضو غير موجود.\n❌ Member not found.", undefined, true);
      const role = cfg.prisonRoleId ? guild.roles.cache.get(cfg.prisonRoleId) : null;
      if (!role) return reply(interaction, "❌ حدد رتبة السجن أولاً.\n❌ Set the prison role first.", undefined, true);
      if (sub === "add") {
        await member.roles.add(role);
        if (cfg.prisonChannelId) await member.roles.set([role]).catch(() => undefined);
        await logEvent(guild, "mod", "🔒 Prison / سجن", `${member} by ${interaction.user}`);
        return reply(interaction, `✅ تم سجن ${member}.\n✅ ${member} was imprisoned.`);
      }
      await member.roles.remove(role);
      await logEvent(guild, "mod", "🔓 Release / إطلاق", `${member} by ${interaction.user}`);
      return reply(interaction, `✅ تم إطلاق ${member}.\n✅ ${member} was released.`);
    }

    if (command === "study") {
      const sub = interaction.options.getSubcommand();
      const key = "__study" as keyof GuildConfig;
      const state = (cfg as unknown as Record<string, unknown>)[key] as { startedAt: number; endsAt: number } | undefined;
      if (sub === "start") {
        (cfg as unknown as Record<string, unknown>)[key] = { startedAt: Date.now(), endsAt: Date.now() + 2 * 60 * 60 * 1000 };
        await saveStore();
        return reply(interaction, "📚 ✅ بدأت الجلسة الدراسية لمدة ساعتين، ثم استراحة 30 دقيقة.\n📚 ✅ Study session started for two hours, followed by a 30-minute break.");
      }
      if (sub === "stop") {
        delete (cfg as unknown as Record<string, unknown>)[key];
        await saveStore();
        return reply(interaction, "📚 تم إيقاف الجلسة.\n📚 Study session stopped.");
      }
      return reply(interaction, state ? `📚 الجلسة مستمرة حتى <t:${Math.floor(state.endsAt / 1000)}:R>.\n📚 Session continues until <t:${Math.floor(state.endsAt / 1000)}:R>.` : "لا توجد جلسة حالياً.\nNo active session.");
    }

    if (command === "auto") {
      const sub = interaction.options.getSubcommand();
      if (sub === "response-add") cfg.autoResponses[interaction.options.getString("trigger")!.toLowerCase()] = interaction.options.getString("reply")!;
      if (sub === "response-remove") delete cfg.autoResponses[interaction.options.getString("trigger")!.toLowerCase()];
      if (sub === "delete-set") {
        const id = interaction.options.getChannel("channel")!.id;
        if (!cfg.autoDeleteChannels.includes(id)) cfg.autoDeleteChannels.push(id);
      }
      if (sub === "delete-remove") cfg.autoDeleteChannels = cfg.autoDeleteChannels.filter((id) => id !== interaction.options.getChannel("channel")!.id);
      await saveStore();
      if (sub === "response-list") return reply(interaction, Object.entries(cfg.autoResponses).map(([trigger, response]) => `• **${trigger}** → ${response}`).join("\n") || "لا توجد ردود.\nNo responses.", undefined, true);
      return reply(interaction, "✅ تم حفظ إعداد الرد/الحذف التلقائي.\n✅ Auto response/delete setting saved.", undefined, true);
    }

    if (command === "247") {
      const sub = interaction.options.getSubcommand();
      if (sub === "start") {
        const voice = interaction.options.getChannel("channel");
        if (!voice || voice.type !== ChannelType.GuildVoice) return reply(interaction, "❌ اختر روم صوتي.\n❌ Choose a voice channel.", undefined, true);
        cfg.voice247ChannelId = voice.id;
        const connection = joinVoiceChannel({ channelId: voice.id, guildId: guild.id, adapterCreator: guild.voiceAdapterCreator, selfDeaf: false });
        connection.on(VoiceConnectionStatus.Disconnected, async () => {
          if (cfg.voice247ChannelId === voice.id) {
            try { await entersState(connection, VoiceConnectionStatus.Signalling, 5_000); } catch { connection.destroy(); }
          }
        });
        await saveStore();
        return reply(interaction, `✅ البوت الآن في ${voice} بوضع 24/7.\n✅ Bot is now in ${voice} in 24/7 mode.`);
      }
      if (sub === "stop") {
        cfg.voice247ChannelId = null;
        getVoiceConnection(guild.id)?.destroy();
        await saveStore();
        return reply(interaction, "✅ تم إيقاف وضع 24/7.\n✅ 24/7 mode stopped.");
      }
      return reply(interaction, cfg.voice247ChannelId ? `✅ مفعل في <#${cfg.voice247ChannelId}>.\n✅ Active in <#${cfg.voice247ChannelId}>.` : "❌ غير مفعل.\n❌ Not active.");
    }

    const member = interaction.options.getMember("member") as GuildMember | null;
    if (command === "ban" && member) {
      await member.ban({ reason: interaction.options.getString("reason") ?? "No reason" });
      await logEvent(guild, "mod", "🔨 Ban / حظر", `${member.user.tag} by ${interaction.user}`);
      return reply(interaction, `✅ تم حظر ${member.user.tag}.\n✅ ${member.user.tag} was banned.`);
    }
    if (command === "kick" && member) {
      await member.kick(interaction.options.getString("reason") ?? "No reason");
      await logEvent(guild, "mod", "👢 Kick / طرد", `${member.user.tag} by ${interaction.user}`);
      return reply(interaction, `✅ تم طرد ${member.user.tag}.\n✅ ${member.user.tag} was kicked.`);
    }
    if (command === "timeout" && member) {
      const minutes = interaction.options.getInteger("minutes")!;
      await member.timeout(minutes * 60_000, "Moderator timeout");
      await logEvent(guild, "mod", "⏱️ Timeout / كتم", `${member} for ${minutes} minutes by ${interaction.user}`);
      return reply(interaction, `✅ تم كتم ${member} لمدة ${minutes} دقيقة.\n✅ ${member} timed out for ${minutes} minutes.`);
    }
    if (command === "untimeout" && member) {
      await member.timeout(null, "Timeout removed");
      return reply(interaction, `✅ تم رفع الكتم عن ${member}.\n✅ Timeout removed from ${member}.`);
    }
    if (command === "unban") {
      await guild.members.unban(interaction.options.getString("user-id")!);
      return reply(interaction, "✅ تم رفع الحظر.\n✅ User unbanned.");
    }
    if (command === "warn" && member) {
      await member.send(`⚠️ تم تحذيرك في ${guild.name}.\n⚠️ You received a warning in ${guild.name}.\nالسبب / Reason: ${interaction.options.getString("reason")}`).catch(() => undefined);
      await logEvent(guild, "warn", "⚠️ Warning / تحذير", `${member} — ${interaction.options.getString("reason")}`);
      return reply(interaction, `✅ تم تحذير ${member}.\n✅ ${member} was warned.`);
    }
    if (command === "clear") {
      const channel = await requireTextChannel(interaction);
      if (!channel) return;
      const amount = interaction.options.getInteger("amount")!;
      await channel.bulkDelete(amount, true);
      return reply(interaction, `✅ تم حذف ${amount} رسالة.\n✅ Deleted ${amount} messages.`, undefined, true);
    }
    if (command === "heatstrip" && member) {
      await member.roles.set([]);
      await logEvent(guild, "role", "🎭 Roles removed / سُلبت الرتب", `${member} by ${interaction.user}`);
      return reply(interaction, `✅ تم سلب جميع رتب ${member}.\n✅ All roles removed from ${member}.`);
    }
    if (["lock", "unlock", "slowmode", "hide", "unhide"].includes(command)) {
      const channel = await requireTextChannel(interaction);
      if (!channel) return;
      const everyone = guild.roles.everyone;
      if (command === "lock" || command === "unlock") await channel.permissionOverwrites.edit(everyone, { SendMessages: command === "unlock" ? null : false });
      if (command === "slowmode") await channel.setRateLimitPerUser(interaction.options.getInteger("seconds")!);
      if (command === "hide" || command === "unhide") await channel.permissionOverwrites.edit(everyone, { ViewChannel: command === "unhide" ? null : false });
      await logEvent(guild, "mod", `🔧 ${command}`, `${interaction.user} in ${channel}`);
      return reply(interaction, `✅ تم تنفيذ ${command}.\n✅ ${command} completed.`, undefined, true);
    }
  } catch (error) {
    logger.error({ err: error, command, guildId: interaction.guildId }, "Discord command failed");
    return reply(interaction, "❌ حدث خطأ. تأكد من صلاحيات البوت وإعدادات الأمر.\n❌ Something went wrong. Check bot permissions and command settings.", undefined, true);
  }
}

client.on(Events.InteractionCreate, async (interaction) => {
  if (interaction.isChatInputCommand()) await handleCommand(interaction);
  if (interaction.isChannelSelectMenu() && interaction.customId.startsWith("setup:")) {
    const [, stage, action] = interaction.customId.split(":");
    if (action === "channel" && (stage === "welcome" || stage === "ticket" || stage === "level" || stage === "streak")) {
      await handleSetupChannelSelection(interaction, stage);
    }
  }
  if (interaction.isModalSubmit() && interaction.customId.startsWith("setup_")) {
    const stage = interaction.customId.replace("setup_", "").replace("_content", "");
    if (stage === "welcome" || stage === "ticket" || stage === "level" || stage === "streak") {
      await handleSetupModal(interaction, stage);
    }
  }
  if (interaction.isButton()) {
    if (interaction.customId === "setup:begin") {
      await interaction.update(setupChannelPrompt("welcome"));
      return;
    }
    if (interaction.customId === "setup:cancel") {
      setupSessions.delete(setupSessionKey(interaction));
      await interaction.update({
        content: "تم إلغاء الإعداد.\nSetup cancelled.",
        embeds: [],
        components: [],
      });
      return;
    }
    if (interaction.customId === "ticket:open") {
      if (!interaction.guild) return;
      await interaction.deferReply({ ephemeral: true });
      await openTicket(interaction as unknown as ChatInputCommandInteraction, getGuildConfig(interaction.guild.id));
    }
    if (interaction.customId === "ticket:close") {
      if (!interaction.guild || !interaction.channel || interaction.channel.type !== ChannelType.GuildText) return;
      if (!interaction.channel.name.startsWith("ticket-") && !interaction.memberPermissions?.has(PermissionFlagsBits.ManageChannels)) {
        await interaction.reply({ content: "❌ لا تملك صلاحية إغلاق هذه التذكرة.\n❌ You cannot close this ticket.", ephemeral: true });
        return;
      }
      await interaction.reply("✅ سيتم إغلاق التذكرة.\n✅ Ticket closing.");
      await logEvent(interaction.guild, "ticket", "🎫 Ticket closed / أغلقت التذكرة", `${interaction.channel} by ${interaction.user}`);
      setTimeout(() => interaction.channel?.delete("Ticket closed").catch(() => undefined), 1_500);
    }
  }
});

client.on(Events.GuildMemberAdd, async (member) => {
  const cfg = getGuildConfig(member.guild.id);
  if (cfg.welcomeChannelId) {
    const channel = await member.guild.channels.fetch(cfg.welcomeChannelId).catch(() => null);
    if (channel?.type === ChannelType.GuildText) await channel.send(mediaPayload(replaceVars(cfg.welcomeText, { user: member.user } as unknown as ChatInputCommandInteraction), cfg.welcomeImage)).catch(() => undefined);
  }
  await logEvent(member.guild, "join", "👋 Member joined / انضم عضو", `${member} — ${member.user.tag}`);
});

client.on(Events.GuildMemberRemove, async (member) => {
  await logEvent(member.guild, "leave", "🚪 Member left / غادر عضو", `${member.user.tag} (${member.id})`);
});

client.on(Events.MessageCreate, async (message: Message) => {
  if (!message.guild || message.author.bot) return;
  const cfg = getGuildConfig(message.guild.id);
  const progress = progressFor(cfg, message.author.id);
  const oldLevel = progress.level;
  progress.xp += 1;
  progress.level = levelForXp(progress.xp);
  if (progress.level > oldLevel) {
    await updateLevelRole(message.member!, progress.level);
    if (cfg.levelChannelId) {
      const channel = await message.guild.channels.fetch(cfg.levelChannelId).catch(() => null);
      if (channel?.type === ChannelType.GuildText) await channel.send(mediaPayload(replaceVars(cfg.levelText, message as unknown as ChatInputCommandInteraction, { level: String(progress.level) }), cfg.levelImage)).catch(() => undefined);
    }
    await logEvent(message.guild, "server", "⭐ Level up / ارتفع المستوى", `${message.author} reached level ${progress.level}`);
  }
  const response = Object.entries(cfg.autoResponses).find(([trigger]) => message.content.toLowerCase().includes(trigger));
  if (response) await (message.channel as TextChannel).send(response[1]).catch(() => undefined);
  if (cfg.autoDeleteChannels.includes(message.channelId)) await message.delete().catch(() => undefined);
  if (progress.xp % 10 === 0) await saveStore();
});

client.on(Events.MessageDelete, async (message) => {
  if (message.guild && !message.author?.bot) await logEvent(message.guild, "message", "🗑️ Message deleted / حُذفت رسالة", `Channel: <#${message.channelId}>`);
});

client.on(Events.MessageUpdate, async (oldMessage, newMessage) => {
  if (newMessage.guild && !newMessage.author?.bot && oldMessage.content !== newMessage.content) {
    await logEvent(newMessage.guild, "message", "✏️ Message edited / عُدلت رسالة", `Channel: <#${newMessage.channelId}>\nBefore: ${oldMessage.content ?? "?"}\nAfter: ${newMessage.content ?? "?"}`);
  }
});

client.on(Events.ChannelCreate, async (channel) => {
  if (channel.guild) await logEvent(channel.guild, channel.type === ChannelType.GuildCategory ? "category" : "channel", "📁 Channel created / أُنشئ روم", `${channel}`);
});
client.on(Events.ChannelDelete, async (channel) => {
  if ("guild" in channel && channel.guild && "name" in channel) await logEvent(channel.guild, channel.type === ChannelType.GuildCategory ? "category" : "channel", "📁 Channel deleted / حُذف روم", `${channel.name}`);
});
client.on(Events.GuildRoleCreate, async (role) => logEvent(role.guild, "role", "🎭 Role created / أُنشئت رتبة", role.name));
client.on(Events.GuildRoleDelete, async (role) => logEvent(role.guild, "role", "🎭 Role deleted / حُذفت رتبة", role.name));
client.on(Events.Error, (error) => logger.error({ err: error }, "Discord client error"));

export async function startDiscordBot() {
  const token = process.env.DISCORD_TOKEN;
  if (!token) {
    logger.warn("DISCORD_TOKEN is not configured; Discord bot is disabled.");
    return;
  }
  await initStore();
  client.once(Events.ClientReady, async (readyClient) => {
    const rest = new REST({ version: "10" }).setToken(token);
    await rest.put(Routes.applicationCommands(readyClient.user.id), { body: commands.map((command) => command.toJSON()) });
    logger.info({ user: readyClient.user.tag, guilds: readyClient.guilds.cache.size }, "Discord bot is ready");
  });
  await client.login(token);
}