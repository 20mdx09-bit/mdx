import type { LogKind } from "./types";

export const LOG_NAMES: Record<LogKind, string> = {
  join: "انضمام / Join",
  leave: "مغادرة / Leave",
  message: "رسائل / Messages",
  voice: "صوتي / Voice",
  mod: "إشراف / Moderation",
  warn: "تحذيرات / Warnings",
  role: "رتب / Roles",
  channel: "رومات / Channels",
  category: "أقسام / Categories",
  bot: "بوت / Bot",
  server: "سيرفر / Server",
  invite: "دعوات / Invites",
  ticket: "تذاكر / Tickets",
};

export const ROLE_DEFINITIONS = [
  { name: "👑 𝑂𝑤𝑛𝑒𝑟", color: "#8B0000" },
  { name: "🛡️ 𝐶𝑜-𝑂𝑤𝑛𝑒𝑟", color: "#DC143C" },
  { name: "⚜️ 𝐻𝑒𝑎𝑑 𝐴𝑑𝑚𝑖𝑛", color: "#FFD700" },
  { name: "🔰 𝐴𝑑𝑚𝑖𝑛", color: "#FF8C00" },
  { name: "🛠️ 𝑆𝑒𝑛𝑖𝑜𝑟 𝑀𝑜𝑑", color: "#FF6600" },
  { name: "🛡️ 𝑀𝑜𝑑𝑒𝑟𝑎𝑡𝑜𝑟", color: "#1E90FF" },
  { name: "📝 𝑇𝑟𝑖𝑎𝑙 𝑀𝑜𝑑", color: "#00FFFF" },
  { name: "🤖 𝐵𝑜𝑡", color: "#9932CC" },
  { name: "💎 𝑉𝐼𝑃", color: "#FF69B4" },
  { name: "🌟 𝐵𝑜𝑜𝑠𝑡𝑒𝑟", color: "#FF00FF" },
  { name: "💻 𝐷𝑒𝑣𝑒𝑙𝑜𝑝𝑒𝑟", color: "#4B0082" },
  { name: "🎨 𝐷𝑒𝑠𝑖𝑔𝑛𝑒𝑟", color: "#800080" },
  { name: "🎮 𝐺𝑎𝑚𝑒𝑟", color: "#32CD32" },
  { name: "✅ 𝑉𝑒𝑟𝑖𝑓𝑖𝑒𝑑", color: "#008000" },
  { name: "👤 𝑀𝑒𝑚𝑏𝑒𝑟", color: "#90EE90" },
  { name: "🌱 𝑁𝑒𝑤 𝑀𝑒𝑚𝑏𝑒𝑟", color: "#90EE90" },
  { name: "🔇 𝑀𝑢𝑡𝑒𝑑", color: "#696969" },
];

export const LEVEL_DEFINITIONS = [
  [1, "Level 1 | Newbie"],
  [5, "Level 5 | Starter"],
  [10, "Level 10 | Explorer"],
  [20, "Level 20 | Active"],
  [30, "Level 30 | Regular"],
  [40, "Level 40 | Veteran"],
  [50, "Level 50 | Elite"],
  [60, "Level 60 | Master"],
  [70, "Level 70 | Legend"],
  [80, "Level 80 | Mythic"],
  [90, "Level 90 | Ancient"],
  [100, "Level 100 | Immortal"],
] as const;

export const CHANNEL_LAYOUT = {
  "𓍯 Welcome": {
    text: ["👋・welcome", "📜・rules", "📢・announcements", "🎭・roles", "📌・server-info"],
    voice: [],
  },
  "𓍯 Community": {
    text: ["💬・general", "😂・memes", "🔥・streak", "📸・media", "🎮・gaming-chat", "🎵・music-chat", "🤖・bot-commands", "💡・suggestions"],
    voice: [],
  },
  "𓍯 Voice": {
    text: [],
    voice: ["🔊・Voice 1", "🎧・Voice 2", "🎮・Gaming", "🎵・Music", "🌙・AFK"],
  },
  "𓍯 Logs": {
    text: ["👋・join-logs", "🚪・leave-logs", "💬・message-logs", "🎙️・voice-logs", "🔨・mod-logs", "⚠️・warn-logs", "🎭・role-logs", "📁・channel-logs", "📂・category-logs", "🤖・bot-logs", "⚙️・server-logs", "📨・invite-logs", "🎫・ticket-logs"],
    voice: [],
  },
  "𓍯 Staff": {
    text: ["💬・staff-chat", "📋・staff-notes", "🚨・reports", "📊・staff-meeting"],
    voice: [],
  },
  "𓍯 Management": {
    text: ["👑・owner-chat", "⚡・admin-chat", "🤖・bot-control", "🔐・private"],
    voice: [],
  },
  "𓍯 Support": {
    text: ["🎫・tickets"],
    voice: [],
  },
} as const;

export const HELP_CATEGORIES: Record<string, string[]> = {
  "🛡️ الإشراف / Moderation": ["/ban", "/kick", "/timeout", "/untimeout", "/unban", "/warn", "/clear", "/heatstrip", "/lock", "/unlock", "/slowmode", "/hide", "/unhide"],
  "⚙️ الإعدادات / Setup": ["/setup", "/build-server", "/organize-server", "/reset-server", "/setup-roles", "/setup-channels", "/set"],
  "🎟️ التذاكر / Tickets": ["/ticket create", "/ticket close", "/ticket setup"],
  "🔥 الستريك / Streak": ["/streak daily", "/streak check", "/streak leaderboard"],
  "⭐ المستويات / Levels": ["/rank", "/leaderboard"],
  "📨 الرسائل / Messaging": ["/message dm", "/message dm-all", "/message announce"],
  "🕌 القسم الديني / Islamic": ["/islamic quran", "/islamic dhikr", "/islamic dua"],
  "👑 الإدارة / Admin": ["/prison", "/study", "/auto", "/247"],
  "🎮 الألعاب / Games": ["/game help", "/game coinflip", "/game dice", "/game rps", "/game slots", "/game 8ball", "/game math", "/game trivia", "/game guess-start", "/game guess", "/game blackjack"],
};